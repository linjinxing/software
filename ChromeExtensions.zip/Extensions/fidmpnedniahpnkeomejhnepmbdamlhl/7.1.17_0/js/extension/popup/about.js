$(function() {
	$("#close,#about").click(function() {
		window.close();
	});
});