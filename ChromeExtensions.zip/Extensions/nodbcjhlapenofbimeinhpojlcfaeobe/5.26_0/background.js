﻿
chrome.webRequest.onBeforeRequest.addListener(
  function(details){ 
	try
	{ 
	var newURL, newURLlow;
	newURL = details.url;
	newURLlow = details.url.toLowerCase().replace(/\?q=/g,"&q=");
		if(newURLlow.indexOf("//www.google.")>-1&&newURLlow.indexOf("&q=")>-1) 
		{
			if(newURLlow.indexOf("url=")>0) //go directly
			{
				var urlarr;
				urlarr = newURL.replace('?','&').replace('gsc.','&').split('&');
				for(var i=0;i<urlarr.length;i++)
				{
					if(urlarr[i].indexOf('url=')==0||urlarr[i].indexOf('URL=')==0)
					{
						newURL = urlarr[i].replace('url=','').replace('URL=','');
						newURL = unescape(newURL);
					}
				}
			}
			
			//move to other google
			if(localStorage["mygoogle"].indexOf(".google.")>-1){
				newURL = newURL.replace(/http.?:\/\/www\.google\.com\//,localStorage["mygoogle"]+"/");
				newURL = newURL.replace(/http.?:\/\/www\.google\.com\.hk\//,localStorage["mygoogle"]+"/");
			}
				
			return {redirectUrl: newURL};
		}
		
	}
	catch(err){}
  },
  {urls: ["http://*/*","https://*/*"]},
  ["blocking"]);
/////////////////////////////////
function goGoogleSSL(tabId, changeInfo, tab) {
	try
	{
		chrome.tabs.executeScript(null, {file: "content_script.js", runAt:"document_start"}, function(){});
		if(changeInfo.status=='loading') return;
		function onError(){
			if(tab.url.indexOf(localStorage["mygoogle"])>-1){
				checkallsites(localStorage["mygoogle"]); //alert("yes");
			}
			else{
				var newURL = tab.url.replace(/http.?:\/\/www\.google\..*\//,localStorage["mygoogle"]+"/");
				chrome.tabs.update(tabId, {url : newURL });
			}
		}
		function onSuccess(){}
	
		var newURL, newURLlow;
		newURL = tab.url;
		newURLlow = tab.url.toLowerCase().replace(/\?q=/g,"&q=");
		if(newURLlow.indexOf("//www.google.")>-1&&newURLlow.indexOf("&q=")>-1) 
		{
			    chrome.tabs.executeScript(tabId, {file: 'checkload.js', runAt:"document_start"}, function() {
					var exec_error = setTimeout(onError, 500);
					chrome.tabs.sendRequest(tabId, 'Are you there?', function(yes_no) {
						if (yes_no === 'Yes') {
							clearTimeout(exec_error);
							onSuccess();
						}
					});
				});
		}	
	}
	catch(err)
	{}
}
chrome.tabs.onUpdated.addListener(goGoogleSSL);
////////////////////////////////////////////////////

function getWorkingSite(siteURL){
	if(sessionStorage.getItem("googleisset")== null){
		var xhr = new XMLHttpRequest();
		xhr.open("GET", siteURL+"/search?q=helloworld", true);
		xhr.onreadystatechange = function() 
		{
			if (xhr.readyState == 4){
				try{
					var re = /\<title\>.*\<\/title\>/;
					var varSiteTitle; 

					varSiteTitle = re.exec(xhr.responseText.toString());
					if(varSiteTitle!=null){
						varSiteTitle=varSiteTitle.toString();
						if(varSiteTitle.indexOf("helloworld")>-1){
							if(sessionStorage.getItem("googleisset")== null){
								localStorage["mygoogle"]=siteURL;
								sessionStorage.setItem("googleisset", "Yes");
					
							};
						}
					}
				}
				catch(err){}
			}
		}
		xhr.send();
	};
}
function checkallsites(noURL){
	sessionStorage.removeItem("googleisset");
	try{
	var glist = "https://www.google.fr|https://www.google.de|https://www.google.co.kr|https://www.google.ca|https://www.google.com.au|https://www.google.co.jp|http://www.google.fr|http://www.google.de|http://www.google.co.kr|http://www.google.com.au|http://www.google.ca|http://www.google.co.jp";
	var gurls = glist.split("|");
	for(var n=0; n<=gurls.length; n++){
		if(noURL!=gurls[n]){
			getWorkingSite(gurls[n]);
		}
	}
	}
	catch(err){}
}
checkallsites("begin")
//////////////////////////////////////////////////////

chrome.browserAction.onClicked.addListener(function(tab) {
	newURLlow = tab.url.toLowerCase().replace(/\?q=/g,"&q=");
	if(newURLlow.indexOf("//www.google.")>-1&&newURLlow.indexOf("&q=")>-1) 
	{
		checkallsites(localStorage["mygoogle"]);
		var newURL = tab.url.replace(/http.?:\/\/www\.google\..*\//,localStorage["mygoogle"]+"/");
		chrome.tabs.update(tab.id, {url : newURL });
	}
	else if(newURLlow.indexOf(".google.")>-1||newURLlow.indexOf(".chrome.")>-1||newURLlow.indexOf(".android.")>-1){
		if(newURLlow.indexOf("http://")==0){
			var newURL = tab.url.replace(/http:/,"https:");
			chrome.tabs.update(tab.id, {url : newURL });
		}
		else if(newURLlow.indexOf("https://")==0){
			var newURL = tab.url.replace(/https:/,"http:");
			chrome.tabs.update(tab.id, {url : newURL });
		}
	}

});
