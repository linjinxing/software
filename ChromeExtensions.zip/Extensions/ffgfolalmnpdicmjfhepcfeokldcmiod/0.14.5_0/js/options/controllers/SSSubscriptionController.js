(function() {
    var libs, SSSubscriptionControllerOps;
    libs = ["angular", "jquery", "angular", "services/validate", "options/module", "services/userManager"], 
    SSSubscriptionControllerOps = function(angular,jquery) {
        var SSSubscriptionController, i;
        return SSSubscriptionController = function($scope, $rootScope, $http, $timeout, $translate, $alert, $modal, $log, userManager) {

			  var init;

        $scope.subscription_loading = false;
        $scope.ss_subscription_url = '';
        $rootScope.ss_subscription_accesses = [];

      $scope.showSSClient = function(os) {
        return $rootScope.ssClientModal = $modal({
          templateUrl: "partials/options/modals/ss_client.html",
          controller: 'SSClientController',
          open:true,
          show:true,
          resolve: {
             os: function () {
               return os;
             }
           }
        })
      };

	      $scope.toggleReward = function(div) {
	        	if (jquery('.'+ div + ' .toggle-reward').hasClass('glyphicon-chevron-down')) {
          			jquery('.'+ div + ' .toggle-reward').removeClass('glyphicon-chevron-down');
          			jquery('.'+ div + ' .toggle-reward').addClass('glyphicon-chevron-up');

          			jquery('.'+ div).addClass('slide-up');
                jquery('.'+ div).removeClass('slide-down');
          			jquery('.'+ div + ' .wrapper').slideUp(500);   
	        	}else{ 
          			jquery('.'+ div + ' .toggle-reward').removeClass('glyphicon-chevron-up');
          			jquery('.'+ div + ' .toggle-reward').addClass('glyphicon-chevron-down');
          			jquery('.'+ div).removeClass('slide-up');
                jquery('.'+ div).addClass('slide-down');
          			jquery('.'+ div + ' .wrapper').slideDown(500);   
	        	}  
  	    };


            $rootScope.$watch("user.ss_subscription_url", function(newValue, oldValue) {
                if(!$rootScope.user.ss_subscription_url) return;
  
                $scope.ss_subscription_url = $rootScope.user.ss_subscription_url;
            });

            $rootScope.$watch("user.ss_subscription_accesses", function(newValue, oldValue) {
                if(!$rootScope.user.ss_subscription_accesses) return;
                if(!$scope.subscription_loading) return;
                $scope.subscription_loading = false;
                $rootScope.ss_subscription_accesses = $rootScope.user.ss_subscription_accesses;
            });

      			init = function() {

                userManager.reloadSSSubscription($translate.use().startsWith("en"));

                if(!$scope.subscription_loading && $rootScope.ss_subscription_accesses.length == 0){
                  $scope.subscription_loading = true;
                  userManager.reloadSSSubscriptionAccesses();
                }
      			};


			  return init()
        }, angular.module("options").controller("SSSubscriptionController", SSSubscriptionController)
    }, define(libs, SSSubscriptionControllerOps)
}).call(this);