(function()
{
    var libs,ServerListControllerOps;
    libs= ["angular","jquery_ui","underscore","services/validate","options/module","services/domainManager","services/proxyManager","services/teleScope","services/storage","services/timeUtils","services/domainUtils","services/teleScope","services/streamingServicesManager"],ServerListControllerOps= function(angular,jquery_ui,_)
    {
        var ServerListController,i;
        return ServerListController= function($scope,$rootScope,$translate,$element,$modal,teleScope,storage,proxyManager,streamingServicesManager,SERVERS_MODES,ROLES,LOCALES)
        {
            var bounceWait,bounceTime;
            bounceTime= 0;bounceWait= 10;$scope["lang"]= $translate["use"]();$scope["isp_mode_tips"]= null;var sortServers=function(servers)
            {
                return servers= _["sortBy"](servers,function(server)
                {
                    return -server["score"]
                }
                )
            }
            ;
            $scope["isVIP"]= function()
            {
                return $rootScope["user"]["role"]=== ROLES["VIP"]
            }
            ;function sortableEnable()
            {
                if($rootScope["user"]["role"]!== ROLES["VIP"])
                {
                    return
                }
                $element["find"]('#servers-div .servers-list')["sortable"]({connectWith:'#servers-div .servers-list',placeholder:'placeholder',opacity:0.8,forcePlaceholderSize:true,start:function(ev,ui)
                {
                    if($rootScope["sorting"])
                    {
                        return
                    }
                    $rootScope["sorting"]= true;ui["helper"]["css"]("height","40px");ui["helper"]["height"]("40px")
                }
                ,update:function(ev,ui)
                {
                    var lis=$element["find"]('#servers-div .server-item');
                    var ret=[];
                    $rootScope["servers_loading"]= true;$rootScope["sorting"]= false;lis["each"](function()
                    {
                        if(this["id"]!= '')
                        {
                            ret["push"](this["id"])
                        }
                    }
                    );if(ret["length"]> 0)
                    {
                        $rootScope["servers_order"]= ret
                    }
                    setTimeout(function()
                    {
                        $rootScope["servers_loading"]= false;$scope.$apply()
                    }
                    ,600)
                }
                });$element["find"]('#servers-div .servers-list')["sortable"]("option","disabled",false);$element["find"]('#servers-div .servers-list')["disableSelection"]();return false
            }
            function sortableDisable()
            {
                $element["find"]('#servers-div .servers-list')["sortable"]("disable");return false
            }
            if($rootScope["user"]["role"]=== ROLES["VIP"])
            {
                sortableEnable();if($rootScope["servers_mode"]=== SERVERS_MODES["MANUAL"])
                {
                }
                else 
                {
                    sortableDisable()
                }
                $rootScope.$watch('servers_mode',function()
                {
                    if($rootScope["servers_mode"]&& $rootScope["servers_mode"]=== SERVERS_MODES["MANUAL"])
                    {
                        sortableEnable();$rootScope["serversmodeChecked"]= true
                    }
                    else 
                    {
                        sortableDisable();$rootScope["serversmodeChecked"]= false
                    }
                }
                )
            }
            $scope["makeLowerCase"]= function(string)
            {
                return string["toLowerCase"]()
            }
            ;$scope["showRoutingTutorialPlay"]= function()
            {
                return $rootScope["routingTutorialAutoPlayModal"]= $modal({templateUrl:"partials/options/modals/routing_tutorial_auto_play.html",show:true,backdrop:true})
            }
            ;$scope["showISPTutorialPlay"]= function()
            {
                return $rootScope["routingTutorialAutoPlayModal"]= $modal({templateUrl:"partials/options/modals/isp_tutorial_auto_play.html",show:true,backdrop:true})
            }
            ;$scope["showStreamingServicesTutorialPlay"]= function()
            {
                return $rootScope["streamingServicesTutorialAutoPlayModal"]= $modal({templateUrl:"partials/options/modals/streaming_services_tutorial_auto_play.html",show:true,backdrop:true})
            }
            ;$scope["serversmodeChanged"]= function()
            {
                if($rootScope["serversmodeChecked"])
                {
                    $rootScope["servers_mode"]= SERVERS_MODES["MANUAL"];var lis=$element["find"]('#servers-div .server-item');
                    var ret=[];
                    lis["each"](function()
                    {
                        if(this["id"]!= '')
                        {
                            console["log"](this["id"]);ret["push"](this["id"])
                        }
                    }
                    );if(ret["length"]> 0)
                    {
                        $rootScope["servers_order"]= ret
                    }
                }
                else 
                {
                    $rootScope["servers_mode"]= SERVERS_MODES["AUTO"];$rootScope["servers_order"]= []
                }
            }
            ;$scope["showMoreStreamingServices"]= function(server)
            {
                if($rootScope["moreStreamingServicesModal"])
                {
                    $rootScope["moreStreamingServicesModal"]["hide"]();$rootScope["moreStreamingServicesModal"]["destroy"]();$rootScope["moreStreamingServicesModal"]= null
                }
                $rootScope["clickedServer"]= server;return $rootScope["moreStreamingServicesModal"]= $modal({templateUrl:"partials/options/modals/more_streaming_services_alert.html",show:true,size:'lg',backdrop:true})
            }
            ;$scope["getSpecials"]= function(server)
            {
                return streamingServicesManager["getSpecials"](server)
            }
            ;$scope["isNetflix"]= function(special)
            {
                return streamingServicesManager["isNetflix"](special)
            }
            ;$scope["netflixWithArea"]= function(special)
            {
                return streamingServicesManager["netflixWithArea"](special)
            }
            ;$scope["isHulu"]= function(special)
            {
                return streamingServicesManager["isHulu"](special)
            }
            ;$scope["hulu"]= function(special)
            {
                return streamingServicesManager["hulu"](special)
            }
            ;$scope["isAbematv"]= function(special)
            {
                return streamingServicesManager["isAbematv"](special)
            }
            ;$scope["abematv"]= function(special)
            {
                return streamingServicesManager["abematv"](special)
            }
            ;$scope["isHappyon"]= function(special)
            {
                return streamingServicesManager["isHappyon"](special)
            }
            ;$scope["happyon"]= function(special)
            {
                return streamingServicesManager["happyon"](special)
            }
            ;$scope["isHbo"]= function(special)
            {
                return streamingServicesManager["isHbo"](special)
            }
            ;$scope["hbo"]= function(special)
            {
                return streamingServicesManager["hbo"](special)
            }
            ;$scope["isHbogo"]= function(special)
            {
                return streamingServicesManager["isHbogo"](special)
            }
            ;$scope["hbogo"]= function(special)
            {
                return streamingServicesManager["hbogo"](special)
            }
            ;$scope["isHbonow"]= function(special)
            {
                return streamingServicesManager["isHbonow"](special)
            }
            ;$scope["hbonow"]= function(special)
            {
                return streamingServicesManager["hbonow"](special)
            }
            ;$scope["isBbc"]= function(special)
            {
                return streamingServicesManager["isBbc"](special)
            }
            ;$scope["bbc"]= function(special)
            {
                return streamingServicesManager["bbc"](special)
            }
            ;$scope["isTvb"]= function(special)
            {
                return streamingServicesManager["isTvb"](special)
            }
            ;$scope["tvb"]= function(special)
            {
                return streamingServicesManager["tvb"](special)
            }
            ;$scope["isSling"]= function(special)
            {
                return streamingServicesManager["isSling"](special)
            }
            ;$scope["sling"]= function(special)
            {
                return streamingServicesManager["sling"](special)
            }
            ;$scope["isDisneyPlus"]= function(special)
            {
                return streamingServicesManager["isDisneyPlus"](special)
            }
            ;$scope["disneyPlus"]= function(special)
            {
                return streamingServicesManager["disneyPlus"](special)
            }
            ;$scope["isFoxPlus"]= function(special)
            {
                return streamingServicesManager["isFoxPlus"](special)
            }
            ;$scope["foxPlus"]= function(special)
            {
                return streamingServicesManager["foxPlus"](special)
            }
            ;$scope["isFoxNews"]= function(special)
            {
                return streamingServicesManager["isFoxNews"](special)
            }
            ;$scope["foxNews"]= function(special)
            {
                return streamingServicesManager["foxNews"](special)
            }
            ;$scope["isNico"]= function(special)
            {
                return streamingServicesManager["isNico"](special)
            }
            ;$scope["nico"]= function(special)
            {
                return streamingServicesManager["nico"](special)
            }
            ;$scope["isDmm"]= function(special)
            {
                return streamingServicesManager["isDmm"](special)
            }
            ;$scope["dmm"]= function(special)
            {
                return streamingServicesManager["dmm"](special)
            }
            ;$scope["isTver"]= function(special)
            {
                return streamingServicesManager["isTver"](special)
            }
            ;$scope["tver"]= function(special)
            {
                return streamingServicesManager["tver"](special)
            }
            ;$scope["isTWGamer"]= function(special)
            {
                return streamingServicesManager["isTWGamer"](special)
            }
            ;$scope["twGamer"]= function(special)
            {
                return streamingServicesManager["twGamer"](special)
            }
            ;$scope["isVrv"]= function(special)
            {
                return streamingServicesManager["isVrv"](special)
            }
            ;$scope["vrv"]= function(special)
            {
                return streamingServicesManager["vrv"](special)
            }
            ;$scope["isViu"]= function(special)
            {
                return streamingServicesManager["isViu"](special)
            }
            ;$scope["viu"]= function(special)
            {
                return streamingServicesManager["viu"](special)
            }
            ;$scope["is4gtv"]= function(special)
            {
                return streamingServicesManager["is4gtv"](special)
            }
            ;$scope["fourgtv"]= function(special)
            {
                return streamingServicesManager["fourgtv"](special)
            }
            ;$scope["switchMode"]= function(mode)
            {
                if(mode!== $rootScope["mode"])
                {
                    $rootScope["mode"]= mode
                }
                return false
            }
            ;$scope["showModeTips"]= function(n)
            {
                if("auto"=== n)
                {
                    return $scope["mode_tips"]= $translate["instant"]("popup.menu.auto.desc")
                }
                else 
                {
                    if("always"=== n)
                    {
                        return $scope["mode_tips"]= $translate["instant"]("popup.menu.always.desc")
                    }
                    else 
                    {
                        if("never"=== n)
                        {
                            return $scope["mode_tips"]= $translate["instant"]("popup.menu.never.desc")
                        }
                        else 
                        {
                            $scope["mode_tips"]= null
                        }
                    }
                }
            }
            ;$scope["switchISPMode"]= function(mode)
            {
                if(mode=== $rootScope["isp_mode"])
                {
                    proxyManager["reloadServers"]($rootScope["isp_mode"],$rootScope["destination"])
                }
                $rootScope["isp_mode"]= mode;$rootScope["servers_loading"]= true
            }
            ;$scope["switchDestination"]= function(destination)
            {
                if(destination=== $rootScope["destination"])
                {
                    proxyManager["reloadServers"]($rootScope["isp_mode"],$rootScope["destination"])
                }
                $rootScope["destination"]= destination;$rootScope["servers_loading"]= true
            }
            ;$scope["serversModeTooltip"]= function()
            {
                if($rootScope["serversmodeChecked"])
                {
                    return $translate["instant"]("popup.settings.servers_mode_manual.detailed_desc")
                }
                else 
                {
                    return $translate["instant"]("popup.settings.servers_mode_auto.detailed_desc")
                }
            }
            ;$scope["destinationTooltip"]= function(destination)
            {
                return $translate["instant"]("country."+ destination)
            }
            ;$scope["reloadProxies"]= function()
            {
                $rootScope["servers_loading"]= true;proxyManager["reloadServers"]("all")
            }
        }
        ,angular["module"]("options")["controller"]("ServerListController",['$scope','$rootScope','$translate','$element','$modal','teleScope','storage','proxyManager','streamingServicesManager','SERVERS_MODES','ROLES','LOCALES',ServerListController])
    }
    ,define(libs,ServerListControllerOps)
}
)["call"](this)