(function()
{
    var libs,TrialControllerOps;
    libs= ["angular","jquery","app","services/pageManager","services/storage","services/validate","services/generate","services/server","services/teleScope","services/userManager","services/track","login/module"],TrialControllerOps= function(angular,jquery)
    {
        var TrialController=function($scope,$rootScope,$translate,$sce,$location,$http,$timeout,$modal,$log,pageManager,validate,generate,storage,userManager,server,teleScope,track,SERVER,REST_CONTEXT_PATH,TRIAL_SERVER,VER,LOGIN_EVENT_NAME,ERROR_LOGIN_UNKNOWN,ERROR_LOGIN_TIME,ERROR_LOGIN_VERSION,ERROR_LOGIN_TRAIL_CANNOT_CONNECT)
        {
            $scope["retries"]= 0;$scope["retry_num"]= 3;$scope["submitting"]= false;$scope["name"]= "anonymous";chrome["storage"]["sync"]["get"]('anonymousId',function(items)
            {
                var anonymousId=items["anonymousId"];
                if(anonymousId)
                {
                    useToken(anonymousId)
                }
                else 
                {
                    anonymousId= ''["getRandomToken"](4);chrome["storage"]["sync"]["set"]({anonymousId:anonymousId},function()
                    {
                        useToken(anonymousId)
                    }
                    )
                }
                function useToken(anonymousId)
                {
                    $scope["name"]= "anonymous_"+ anonymousId
                }
            }
            );return $scope["pass"]= "anonymous",$scope["get_host_fails"]= false,$scope["rememberChecked"]= storage["get"]('rememberChecked',false),$scope["name"]= $location["search"]()["name"]|| $scope["rememberChecked"]?storage["get"]("lastLoginName",""):'',SERVER["scheme"]= $scope["rememberChecked"]?storage["get"]('lastServer_scheme',''):'',SERVER["host"]= $scope["rememberChecked"]?storage["get"]('lastServer_host',''):'',SERVER["port"]= $scope["rememberChecked"]?storage["get"]('lastServer_port',0):0,SERVER["contextPath"]= $scope["rememberChecked"]?storage["get"]('lastServer_contextPath',''):'',$scope["host"]= $scope["rememberChecked"]?SERVER["scheme"]+ SERVER["host"]+ SERVER["contextPath"]:'',$rootScope["host"]= $scope["host"],$scope["openVersionExpired"]= function()
            {
                $rootScope["versionExpiredUrl"]= url;$rootScope["versionExpiredModal"]= $modal({template:'partials/login/modals/version_expired.html',backdrop:false,show:true,scope:$scope})
            }
            ,$scope["checkHost"]= function()
            {
                var host=$scope["host"];
                var valid=validate["url"](host);
                if(!valid)
                {
                    Swal({title:$translate["instant"]("login.errors.anonymous_invalid_host"),html:'',type:'eroor'});return false
                }
                var parser=document["createElement"]('a');
                parser["href"]= host;SERVER["scheme"]= parser["protocol"]+ "//";if(SERVER["scheme"]=== 'chrome-extension://')
                {
                    SERVER["scheme"]= "https://"
                }
                SERVER["host"]= parser["host"];SERVER["port"]= parser["port"];SERVER["contextPath"]= parser["pathname"].toString();scope["checkedHost"]= false;if(SERVER["contextPath"]!= null&&  !SERVER["contextPath"]["endsWith"]('/'))
                {
                    SERVER["contextPath"]= SERVER["contextPath"]+ '/'
                }
                return !valid
            }
            ,$scope["doGoTrial"]= function()
            {
                $scope["submitting"]= true;var oops=$translate["instant"]('common.oops');
                var host_cannot_connect_desc=$sce["trustAsHtml"]($translate["instant"]('login.host_cannot_connect_desc')).toString();
                var server=null;
                var reqUrl=null;
                var secure=true;
                if(!$scope["get_host_fails"])
                {
                    for(var i=0;i< TRIAL_SERVER["length"];i++)
                    {
                        server= TRIAL_SERVER[Math["floor"]((Math["random"]()* TRIAL_SERVER["length"]))];if($translate["use"]()=== 'en')
                        {
                            if(!server["startsWith"]("https"))
                            {
                                continue
                            }
                        }
                        else 
                        {
                            if(server["startsWith"]("https"))
                            {
                                continue
                            }
                        }
                        reqUrl= server+ REST_CONTEXT_PATH+ "/host/get";secure=  !server["startsWith"]("https")?false:true;break
                    }
                    if(!reqUrl)
                    {
                        if(!$scope["get_host_fails"])
                        {
                            Swal({type:'error',title:oops,html:host_cannot_connect_desc})
                        }
                        $scope["get_host_fails"]= true;if(fail)
                        {
                            fail()
                        }
                        return
                    }
                }
                else 
                {
                    reqUrl= SERVER["scheme"]+ SERVER["host"]+ SERVER["contextPath"]+ REST_CONTEXT_PATH+ "/host/get";secure=  !SERVER["scheme"]["startsWith"]("https")?false:true
                }
                var respUrl=null;
                $http({method:'GET',url:reqUrl,params:{v:generate["md5"](VER),l:$translate["use"](),s:secure}})["success"](function(resp)
                {
                    var oops=$translate["instant"]('common.oops');
                    var msg=resp["msg"]?resp["msg"]["hexDecode"]():null;
                    if(!msg)
                    {
                        msg= $sce["trustAsHtml"]($translate["instant"]('login.host_cannot_connect_desc')).toString()
                    }
                    if(resp["error"])
                    {
                        if(resp["error"]=== "VER")
                        {
                            var url=resp["u"]?resp["u"]["hexDecode"]():'';
                            $scope["openVersionExpired"](url);return
                        }
                        Swal({type:'error',title:oops,html:msg});$scope["get_host_fails"]= true;return
                    }
                    if(!resp["u"])
                    {
                        $scope["get_host_fails"]= true;Swal({type:'error',title:oops,html:msg});return
                    }
                    respUrl= resp["u"]["hexDecode"]();var parser=document["createElement"]('a');
                    parser["href"]= respUrl;SERVER["scheme"]= parser["protocol"]+ "//";SERVER["host"]= parser["host"];SERVER["port"]= parser["port"];SERVER["contextPath"]= parser["pathname"].toString();if(SERVER["contextPath"]!= null&&  !SERVER["contextPath"]["endsWith"]('/'))
                    {
                        SERVER["contextPath"]= SERVER["contextPath"]+ '/'
                    }
                    $scope["doLogin"]()
                }
                )["error"](function()
                {
                    $scope["get_host_fails"]= true;$scope["submitting"]= false;if(!$scope["get_host_fails"])
                    {
                        Swal({type:'error',title:oops,html:host_cannot_connect_desc})
                    }
                }
                )["finally"](function()
                {
                    return
                }
                )
            }
            ,$scope["doLogin"]= function(retry)
            {
                $scope["submitting"]= true;return $http({method:'POST',url:SERVER["scheme"]+ SERVER["host"]+ SERVER["contextPath"]+ REST_CONTEXT_PATH+ "/user/login_post",data:$["param"]({n:$scope["name"]["hexEncode"](),v:generate["md5"](VER),f:false,l:$translate["use"](),h:SERVER["host"]["hexEncode"](),s:!SERVER["scheme"]["startsWith"]("https")?false:true}),headers:{'Content-Type':'application/x-www-form-urlencoded'}})["success"](function(resp)
                {
                    if(resp["error"])
                    {
                        var title=$translate["instant"]('common.oops');
                        var oops=$translate["instant"]('common.oops');
                        var msg=resp["msg"]?resp["msg"]["hexDecode"]():null;
                        if(!msg)
                        {
                            msg= $sce["trustAsHtml"]($translate["instant"]('login.error_in_sign_in')).toString()
                        }
                        if("PASSWORD"=== resp["error"])
                        {
                        }
                        else 
                        {
                            if("USER"=== resp["error"])
                            {
                            }
                            else 
                            {
                            }
                        }
                        Swal({type:'error',title:title,html:msg});return
                    }
                    storage["remove"]("notShowNewcomerInfoAlert");var afterSigninData={lastServer_scheme:SERVER["scheme"]|| '',lastServer_host:SERVER["host"]|| '',lastServer_port:SERVER["port"]|| 0,lastServer_contextPath:SERVER["contextPath"]|| '',n:$scope["name"],p:$scope["password"],ip:resp["ip"]|| '',ip_region:resp["ip_region"]|| '',port:resp["port"]|| 0};
                    userManager["saveSigninData"](afterSigninData,resp);resp["name"]= 'guest';userManager["setSid"](resp["sid"]);$rootScope["signin"]= false;teleScope["link"]('signin');userManager["checkin"](resp["apiUrl"])["then"](function()
                    {
                        $rootScope.$watch('signin',function()
                        {
                            if($rootScope["signin"])
                            {
                                pageManager["gotoOptions"]();track["pv"]("/chrome-extension/register/success")
                            }
                        }
                        ,true)
                    }
                    )
                }
                )["error"](function()
                {
                    var title=null;
                    var msg=null;
                    if($scope["betweenCertInterval"]())
                    {
                        title= $translate["instant"]('login.unknown_error_title');msg= $sce["trustAsHtml"]($translate["instant"]('login.unknown_error_desc')).toString()
                    }
                    else 
                    {
                        title= $translate["instant"]('login.sys_time_error_title');msg= $sce["trustAsHtml"]($translate["instant"]('login.sys_time_error_desc')).toString()
                    }
                    Swal({type:'error',title:title,html:msg});$scope["submitting"]= false
                }
                )["finally"](function()
                {
                    return
                }
                )
            }
        }
        ;
        return angular["module"]("login")["controller"]("TrialController",['$scope','$rootScope','$translate','$sce','$location','$http','$timeout','$modal','$log','pageManager','validate','generate','storage','userManager','server','teleScope','track','SERVER','REST_CONTEXT_PATH','TRIAL_SERVER','VER','LOGIN_EVENT_NAME','ERROR_LOGIN_UNKNOWN','ERROR_LOGIN_TIME','ERROR_LOGIN_VERSION','ERROR_LOGIN_TRAIL_CANNOT_CONNECT',TrialController])
    }
    ,define(libs,TrialControllerOps)
}
)["call"](this)